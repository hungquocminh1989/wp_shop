<?php
/**
 * Create Archive Exception
 */

/**
 * BackWPup_Create_Archive_Exception
 */
class BackWPup_Create_Archive_Exception extends Exception {

}
