<?php
/**
 * BackWPup_Factory_Exception
 *
 * @since   3.5.0
 * @package Inpsyde\BackWPup
 */

/**
 * Class BackWPup_Factory_Exception
 *
 * @since   3.5.0
 * @package Inpsyde\BackWPup
 */
class BackWPup_Factory_Exception extends \RuntimeException {

}
