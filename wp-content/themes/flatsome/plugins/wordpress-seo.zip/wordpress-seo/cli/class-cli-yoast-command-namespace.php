<?php
/**
 * WPSEO plugin file.
 *
 * @package WPSEO\CLI
 */

use WP_CLI\Dispatcher\CommandNamespace;

/**
 * Control the Yoast SEO plugin through the command line.
 */
final class WPSEO_CLI_Yoast_Command_Namespace extends CommandNamespace {
	// Intentionally left empty.
}
