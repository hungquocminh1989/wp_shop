<?php
namespace W3TC;

define( 'W3TC_CDN_EDGECAST_PURGE_URL', 'http://api.acdn.att.com/v2/mcc/customers/%s/edge/purge' );

/**
 * class CdnEngine_Mirror_Att
 */
class CdnEngine_Mirror_Att extends CdnEngine_Mirror_Edgecast {

}
