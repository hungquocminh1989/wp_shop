=== Advanced Custom Fields options import/export ===
Contributors: olezhyk5
Author URI: http://thewpdev.org/
Tags: acf, Advanced Custom Fields, acf options import, acf options export
Requires at least: 4.0
Tested up to: 5.2.2
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Advanced Custom Fields options import/export

== Description ==

This plugin allows to export and import Advanced Custom Fields options. It also, import and export required images for the options. 

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/acf-impot-export` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Tools -> ACF import/export