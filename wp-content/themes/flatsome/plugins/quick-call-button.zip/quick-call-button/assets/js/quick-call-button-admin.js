jQuery(window).load(function() {	
	
	// add colour pickers
	jQuery('.colourme').wpColorPicker();
	
});
