<h2>
    Bundle listings
</h2>
<p>
    This screen lists all bundles of the current type installed in your WordPress. 
    They may not all be ready for translation, but compatible bundles will show at least one "set" of translatable strings.
</p>
<p>
    Clicking a bundle takes you to its translation management screen.
</p>