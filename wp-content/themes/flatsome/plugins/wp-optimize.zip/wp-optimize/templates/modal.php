<script type="text/html" id="tmpl-wpo-modal">
	<div class="wpo-modal--bg"></div>
	<div class="wpo-modal" tabindex="0">
		<button type="button" class="wpo-modal--close"><span class="dashicons dashicons-no"></span> <span class="screen-reader-text"><?php _e('Close'); ?></button>
		<div class="wpo-modal--content"></div>
	</div>
</script>
